﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using StudentService.Controllers;
using StudentService.Models;
using StudentService.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Test
{
    public class StudentControllerTest
    {
        private readonly Mock<IRepository> service;
        public StudentControllerTest()
        {
            service = new Mock<IRepository>();
        }

        [Fact]
        public void GetStudent_ListOfEmployee_EmployeeExistsInRepo()
        {
            var student = GetStudents();
            service.Setup(x => x.GetAll())
                .Returns(GetStudents());
            var controller = new StudentController(service.Object);

            var actionResult = controller.GetStudents();
            var result = actionResult.Result as OkObjectResult;
            var actual = result.Value as IEnumerable<Student>;

            Assert.Equal(GetStudents().Count(), actual.Count());
        }

        [Fact]
        public void GetStudentByRollNo_shouldReturnBadRequest_StudentNotExists()
        {
            var students = GetStudents();
            Student firstStudent = students.GetEnumerator().Current;
            service.Setup(x => x.GetByRollNo(2))
                .Returns(firstStudent);
            var controller = new StudentController(service.Object);

            var actionResult = controller.GetStudentByRollNo(2);

            var result = actionResult.Result;
            Assert.IsType<NotFoundObjectResult>(result);
        }
        IEnumerable<Student> GetStudents()
        {
            var students = new List<Student>();
            students.Add(new Student() { FirstName = "Bruce", LastName = "Baner", RollNo = 39 });
            students.Add(new Student() { FirstName = "Bruce", LastName = "Wayne", RollNo = 19 });
            students.Add(new Student() { FirstName = "Clerk", LastName = "Kent", RollNo = 1 });
            students.Add(new Student() { FirstName = "Harry", LastName = "Potter", RollNo = 5 });
            return students;
        }
    }
}
