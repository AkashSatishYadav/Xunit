using CalculatorService.Repository;
using Xunit;

namespace CalculatorService.Test
{
    public class CalculatorControllerTest
    {
        private Calculator _unitTesting;

        public CalculatorControllerTest()
        {
            if (_unitTesting == null)
            {
                _unitTesting = new Calculator();
            }
        }

        [Fact]
        public void Add()
        {
            double a = 5;
            double b = 3;
            double expected = 8;

            var actual = _unitTesting.Add(a, b);

            Assert.Equal(expected, actual, 0);
        }


        [Fact]
        public void Substract()
        {
            double x1 = 10;
            double x2 = 8;
            double expected = 2;

            var actual = _unitTesting.Subtract(x1, x2);

            Assert.Equal(expected, actual, 0);
        }

        [Theory(DisplayName = "Divide with parameters")]
        [InlineData(40, 8, 5)]
        public void Divide(double value1, double value2, double value3)
        {
            double x1 = value1;
            double x2 = value2;
            double expected = value3;

            var actual = _unitTesting.Divide(x1, x2);

            Assert.Equal(expected, actual, 0);
        }

        [Fact(DisplayName = "Divide by Zero Exception")]
        public void DivideByZeroException()
        {
            double a = 100;
            double b = 0;

            Action act = () => _unitTesting.Divide(a, b);

            Assert.Throws<DivideByZeroException>(act);
        }
    }
}